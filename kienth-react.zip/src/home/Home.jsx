import DailyDeals from "./DailyDeals";
import Slider from "./Slider";

const Home = () => {
    return (
        <div>
            <Slider />
            <DailyDeals />
        </div>
        
    );
}
 
export default Home;